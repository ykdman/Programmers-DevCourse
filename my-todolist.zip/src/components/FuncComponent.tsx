import React from "react";

function FuncComponent() {
  return <div>함수형 컴포넌트</div>;
}

export default FuncComponent;
